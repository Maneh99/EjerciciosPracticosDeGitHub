public class Main {

    /** PARQUE DE ATRACCIONES */

    public static void main(String[] args) {

        System.out.println("--CHIQUIPARK--");

        /** EJERCICIO 1. */

        System.out.println();
        System.out.println("Ejercicio 1.");
        System.out.println("____________");
        System.out.println();


        Atraccion atraccion = new Atraccion(35, "Montaña Rusa");
        Atraccion atraccion2 = new Atraccion(25, "Coches de choque");

        System.out.println(atraccion.toString()); // .toString no es necesario utilizarlo pero lo he puesto como ejemplo.
        System.out.println(atraccion2);
        System.out.println();// Espacio

        /** EJERCICIO 2. */

        System.out.println("Ejercicio 2.");
        System.out.println("____________");
        System.out.println();

            // Prueba
        atraccion.setCapacidadMaxima(0); // En este caso indica al usuario que no puede ser menor a 1 y hemos cambiado a 0.
                                         // El valor por defecto que hemos puesto es 1 por eso imprime que la capacidad es 1.
        atraccion2.setCapacidadMaxima(-5);
        System.out.println(atraccion);
        System.out.println("---------------");
        System.out.println(atraccion2);
        System.out.println(); // Espacio.


        /** EJERCICIO 3. */

        System.out.println("Ejercicio 3.");
        System.out.println("____________");
        System.out.println();

        Visitante visitante1 = new Visitante("Manu",25);
        Visitante visitante2 = new Visitante("Pablo",4);

        System.out.println(visitante1);
        System.out.println(); // Espacio.
        System.out.println(visitante2);
        System.out.println(); // Espacio.

//        Comentado para realizar el ejercicio 4.
//        visitante2.setEdad(-2); // Cambiamos a una edad negativa.
//        System.out.println(visitante2);
//        System.out.println(); // Espacio.

        /** EJERCICIO 4. */

        System.out.println("Ejercicio 4.");
        System.out.println("____________");
        System.out.println();

        /** EXPLICACIÓN: Esto lo que evita es que el usuario pueda establecer la edad de forma arbitraria
         * de manera incorrecta. ademas esto lo que hace es mantener la integridad de los datos. */


        /** EJERCICIO 5. */

        System.out.println("Ejercicio 5.");
        System.out.println("____________");
        System.out.println();






    }
}