public class Visitante {

    /** 3. Diseñe una clase `Visitante` con los atributos privados `nombre` y `edad`. Cree getters y setters,
     asegurando que la edad no pueda ser negativa. */

    private String nombre;
    private int edad;

     /** CONSTRUCTORES */

     public Visitante() {} // Constructor vacio.

     public Visitante(String nombre, int edad) {
         this.nombre = nombre;
         this.edad = edad;
     }

     /** METODOS */

     /** 4. Elimine el setter de `edad` y cree un mé_todo `cumplirAnios()` que aumente la edad en 1.
      Justifique cómo esto mejora el control del objeto. */

     public void cumplirAnios() { // Metodo cumplir años en vez de setEdad.
         this.edad++;
         System.out.println(nombre + " ahora tiene " + edad + " años");
     }

     /** GETTERS Y SETTERS */

     public String getNombre() {
         return nombre;
     }

     public void setNombre(String nombre) {
         this.nombre = nombre;
     }

     public int getEdad() {
         return edad;
     }

     // Lo he comentado para el ejercicio 4.

//     public void setEdad(int edad) {
//         if (edad < 0 ) {
//             System.out.println("Introduce una edad valida.");
//             this.edad = 0; // Edad por defecto en caso de introducir un valor incorrecto.
//         } else this.edad = edad;
//     }

     public String toString() {
         return "Nombre: " + this.nombre + ", Edad: " + this.edad;
     }
}

