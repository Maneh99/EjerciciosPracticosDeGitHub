public class Atraccion {

    /** 1. Diseñe una clase `Atraccion` con los atributos privados `nombre` y `capacidadMaxima`. Cree los
     getters y setters necesarios y un programa que muestre la información de cada atracción. */

    private int capacidadMaxima;
    private String nombre;


    /** CONSTRUCTORES */

    public Atraccion (){}; // Constructor vacio


    public Atraccion(int capacidadMaxima, String nombre) {
        this.capacidadMaxima = capacidadMaxima;
        this.nombre = nombre;

    }

    /** GETTERS Y SETTERS */

    public int getCapaciadaMaxima() {
        return capacidadMaxima;
    }

    public void setCapacidadMaxima(int capacidadMaxima) {
        // Ejercicio 1. this.capacidadMaxima = capaciadaMaxima;
        /** MODIFICACION EJERCICIO 2. */
        if  (capacidadMaxima <= 1) {
            System.out.println("La capacidad maxima no puede ser menor a 1.");
            this.capacidadMaxima = 1; // Valor para que sea 1.
        } else {
            this.capacidadMaxima = capacidadMaxima;
            // Si no se mete un valor menor que uno se fija la capacidad introducida.
        }
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String toString(){
        return "Nombre de la atracción: " + getNombre() + "." + " Capacidad máxima: " + getCapaciadaMaxima();
    }


}
