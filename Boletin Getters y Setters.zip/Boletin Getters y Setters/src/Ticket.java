public class Ticket {

    /** 5. Diseñe una clase `Ticket` con los atributos privados `numero` y `precio`. Cree getters y setters y
     controle que el precio sea siempre mayor que 0. */

    private int numero;
    private double precio;

    /** CONSTRUCTORES */

    public Ticket (){}

    public Ticket(int numero, double precio) {
        this.numero = numero;
    }

    /** METODOS */

    public void setPrecio(double precio) {
        if (precio <= 0) {
            System.out.println("Error: El precio debe ser mayor que 0");
            this.precio = 1.0; // Precio minimo.
        } else {
            this.precio = precio;
        }
    }

    /** GETTERS Y SETTERS */

    public int getNumero() {
        return numero;
    }
    public void setNumero(int numero) {
        this.numero = numero;
    }

    public double getPrecio() {
        return precio;
    }

    public String toString() {
        return "Ticket: " + "Numero: " + numero + ". " + " Precio: " + precio;
    }


}
