import java.util.Scanner;

public class Main {

    static Scanner sc = new Scanner(System.in); // Escaner estatico.

    public static void main(String[] args) {

        Mascota Robin = new Mascota("Perro", "Robin", 3, 5, 7);
        Mascota Laika = new Mascota("Gato", "Laika", 2, 8, 4);
        Mascota Toby = new Mascota("Conejo", "Toby", 1, 3, 9);

        System.out.println("Bienvenido al Refugio");
        System.out.println(); // Para crear espacio de separacion.

        int opcion = 0;

        //Robin.mostrarEstado();

        do {
            System.out.println("\n === REFUGIO ===");
            System.out.println("1. Ver todas las mascotas");
            System.out.println("2. Alimentar a una mascota");
            System.out.println("3. Jugar con una mascota");
            System.out.println("4. Mandar a dormir a una mascota");
            System.out.println("5. Celebrar cumpleaños de una mascota");
            System.out.println("6. Ver estado del refugio");
            System.out.println("7. SALIR");
            System.out.println("Elija una opción");

            opcion = sc.nextInt();

            switch (opcion) {
                case 1 -> {
                    System.out.println("Lita de mascotas");
                    System.out.println("");

                }

            }


        } while (opcion !=7);







    }
}