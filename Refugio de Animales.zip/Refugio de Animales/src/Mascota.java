public class Mascota {
    private String tipo;
    private String nombre;
    private int edad;
    private int hambre;
    private int felicidad;

    Mascota (String tipo, String nombre, int edad, int hambre, int felicidad) {
        this.tipo = tipo;
        this.nombre = nombre;
        this.edad = edad;
        this.hambre = hambre;
        this.felicidad = felicidad;
    }



    public void alimentar (int hambre){
        this.hambre -= 3;

        if (this.hambre < 0 ){ // Esto es para que el hambre no sea menor de 0.
            this.hambre = 0;
        }

        if (this.hambre == 0){ // Si el hambre llega a 0 suma uno a felicidad.
            felicidad++ ;
        }
    }

    public void jugar (int felicidad, int hambre){
        this.felicidad += 2; // Cuando jugamos aumentamos la felicidad en 2.
        this.hambre += 1; // Aumentamos el hambre en un punto.

        if (this.felicidad > 10){ // Para que la felicidad no sea mayor de 10.
            this.felicidad = 10;
        }
    }

    public void dormir (int felicidad, int hambre) {
        this.felicidad += 1;
        this.hambre -= 1;
    }

    public void cumplirAnios (int edad) {
        this.edad = edad++;
    }

    public void mostrarEstado () {
        System.out.println("Tipo de mascota: " + tipo);
        System.out.println("Nombre: " + nombre);
        System.out.println("Edad: " + edad + " años.");
        System.out.println("Hambre: " + hambre);
        System.out.println("Felicidad: " + felicidad);
    }

    public boolean estaTriste (int felicidad) {
         this.felicidad = felicidad;
         return felicidad < 3;
    }

    public boolean tieneHambre (int hambre) {
        this.hambre = hambre;
        return hambre > 7;
    }

}
